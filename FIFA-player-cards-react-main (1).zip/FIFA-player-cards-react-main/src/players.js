var players= [
  {
    id: 1,
    name: "Lionel Messi",
    team: "Inter Miami CF",
    nationality: "Argentinian",
    jerseyNumber: 10,
    age: 36,
    imageUrl: "https://superstarsbio.com/wp-content/uploads/2019/01/Lionel-Messi.jpg"
  },
  {
    id: 2,
    name: "Cristiano Ronaldo",
    team: "Al-Nassr",
    nationality: "Portuguese",
    jerseyNumber: 7,
    age: 39,
    imageUrl: "https://2.bp.blogspot.com/-BnJqpo8DJHk/UOmf9elav-I/AAAAAAAAML8/8fJWdAXZ9Nk/s1600/Portugal-vs-Turkey-cristiano-ronaldo-1499617-1076-1372.jpg"
  },
  {
    id: 3,
    name: "Kylian Mbappé",
    team: "Paris Saint-Germain",
    nationality: "French",
    jerseyNumber: 7,
    age: 25,
    imageUrl: "https://www.diariolibre.com/binrepository/1971x2097/0c20/1970d1024/none/10904/QQVB/kylian-mbappe-ap-2-de-mayo-del-2019_13066214_20200121141422.jpg"
  },
  {
    id: 4,
    name: "Kevin De Bruyne",
    team: "Manchester City",
    nationality: "Belgian",
    jerseyNumber: 17,
    age: 33,
    imageUrl: "https://starsunfolded.com/wp-content/uploads/2018/06/Kevin-de-Bruyne-1.jpg"
  },
  {
    id: 5,
    name: "Neymar Jr.",
    team: "Al-Hilal",
    nationality: "Brazilian",
    jerseyNumber: 10,
    age: 32,
    imageUrl: "https://inspirationseek.com/wp-content/uploads/2016/02/Neymar_08.jpg"
  }
];


  export default players